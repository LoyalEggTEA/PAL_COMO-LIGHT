@echo off
java -jar PalcomAssistant.jar
pause
