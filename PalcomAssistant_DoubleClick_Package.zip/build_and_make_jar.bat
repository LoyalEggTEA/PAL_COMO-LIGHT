@echo off
echo Compiling Java file...
javac PalcomAssistant.java
if %errorlevel% neq 0 (
    echo Compilation failed. Make sure JDK is installed.
    pause
    exit /b
)

echo Creating manifest...
echo Main-Class: PalcomAssistant> manifest.txt

echo Building JAR...
jar cfm PalcomAssistant.jar manifest.txt PalcomAssistant.class

echo Done!
echo You can now double-click PalcomAssistant.jar to run it (if Java is installed).
pause
